package model;

import java.util.Random;
import com.spaceinvaders.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Invader 
{
	private RectF rect;
    private Random generateBullets;
    private Bitmap bitmap1;
    private Bitmap bitmap2;
    private float length;
    private float height;
    private float x;
    private float y;
    private float shipSpeed;
    private int padding;
    private int left = 1;
    private int right = 2;
    private int shipMoving;
    private boolean visibility;
    
    public Invader(Context context, int row, int column, int screenX, int screenY) {
    	//Set the dimensions for the Invaders
        rect = new RectF();//Area occupied by an Invader
        generateBullets = new Random();
        visibility = true;//Has the Invader been killed or not
        length = screenX/15;//Length of Invader
        height = screenY/15;//Height of Invader
        left = 1;//Goes left
        right = 2;//Goes right
        padding = 15;//Space between each Invader
        shipSpeed = 25;//Speed that the Invader's are moving at
        shipMoving = right;//Invader keeps going right until they move to the next line
        x = column * (length + padding);//Invader's position on a column
        y = row * (length + padding);//Invader's position on a row
 
        bitmap1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.ai1);
        bitmap1 = Bitmap.createScaledBitmap(bitmap1, (int)(length), (int)(height), false);
        
        bitmap2 = BitmapFactory.decodeResource(context.getResources(), R.drawable.ai2);
        bitmap2 = Bitmap.createScaledBitmap(bitmap2, (int)(length), (int)(height), false);
    }
    
    public void setInvisible(){
    	visibility = false;
    }
 
    public boolean getVisibility(){
        return visibility;
    }
 
    public RectF getRect(){
        return rect;
    }
 
    public Bitmap getBitmap(){
        return bitmap1;
    }
 
    public Bitmap getBitmap2(){
        return bitmap2;
    }
 
    public float getX(){
        return x;
    }
 
    public float getY(){
        return y;
    }
 
    public float getLength(){
        return length;
    }
    
    public void update(long fps){
        if(shipMoving == left){ //Move left
            x = x - shipSpeed / fps;
        }
     
        if(shipMoving == right){ //Move right
            x = x + shipSpeed / fps;
        }
        
        /** Represents the area around an Invader.
         * Used for the detecting a collision between an Invader and a userBullet so that the userBullet 
         * can hit an Invader and prevent the userBullet from taking out multiple Invaders 
         * instead of just one at a time.
         */
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x + length;     
    }
    
    public void dropDownAndReverse(){
        if(shipMoving == left){
            shipMoving = right;//Invaders goes right if they were going left in the previous row
        }else{
            shipMoving = left;//Invaders goes left if they were going right in the previous row
        }
     
        y = y + height;
        shipSpeed = shipSpeed * 1.18f;
    }
    /** Two ranges of Invader fire: when in sight of the UserShip and 
     * when not in sight of the UserShip.
     *  When not in sight refers to such an instance as when the Invaders and 
     *  the UserShip are at opposite ends of the screen
     *  Not in sight of the UserShip means that Invaders fires at a much smaller rate
     */
    public boolean takeAim(float playerShipX, float playerShipLength){
    	 
/*        int randomNumber = -1;

        if((playerShipX + playerShipLength > x && playerShipX + playerShipLength < x + length) ||
                (playerShipX > x && playerShipX < x + length)) {
     
            //Shoots when in sight of the UserShip
            randomNumber = generateBullets.nextInt(150);
            if(randomNumber == 0) {
                return true;
            }
        }
     
        //Shoots when not in sight of the UserShip
        randomNumber = generateBullets.nextInt(2000);
        if(randomNumber == 0){
            return true;
        }*/
        return false;
    }
}