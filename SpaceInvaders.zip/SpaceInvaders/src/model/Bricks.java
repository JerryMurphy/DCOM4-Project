package model;

import android.graphics.RectF;

public class Bricks 
{
	private RectF rect;
	private boolean isVisible;
	private int width;
	private int height;
	private int shelterPadding;
	private int startHeight;
	
	public Bricks(int row, int column, int shelterNumber, int screenX, int screenY)
	{
	    width = screenX/90;
	    height = screenY/60;
	    isVisible = true;
	    shelterPadding = screenX / 9;
	    startHeight = screenY - (screenY /8 * 2);
	    rect = new RectF(column * width + (shelterPadding * shelterNumber) + shelterPadding + shelterPadding * shelterNumber,
	            row * height + startHeight,
	            column * width + width + (shelterPadding * shelterNumber) + shelterPadding + shelterPadding * shelterNumber,
	            row * height + height+ startHeight);
	}

	public RectF getRect(){
        return this.rect;
    }
 
    public void setInvisible(){
        isVisible = false;
    }
 
    public boolean getVisibility(){
        return isVisible;
    }
}