package com.example.spaceinvaders;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginScreen extends Activity 
{
	EditText usernameField;
    EditText pwordField;
    Button loginButton;
    Button noLoginButton;
    UserDatabase userDatabase;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		userDatabase = new UserDatabase(this);
		setContentView(R.layout.activity_login_screen);
        usernameField = (EditText) findViewById(R.id.usernameField);
        pwordField = (EditText) findViewById(R.id.pwordField);
        loginButton = (Button) findViewById(R.id.loginButton);
        noLoginButton = (Button) findViewById(R.id.noLoginButton);
        
        userDatabase = new UserDatabase(getApplicationContext());
        
        loginButton.setOnClickListener(new View.OnClickListener(){
        	@Override
        	public void onClick(View view){
        		
        		String username = usernameField.getText().toString();
        		String pword = pwordField.getText().toString();

        		String storedUser = userDatabase.getSingleEntry(username);
        		if (pword.equals(storedUser)) {
					Intent i = new Intent(LoginScreen.this, SplashScreen.class);
	                startActivity(i);
        	
				} else {
					Toast.makeText(LoginScreen.this,
							"User Name or Password does not match",
							Toast.LENGTH_LONG).show();
					Log.d("Uname: ", username);
					Log.d("Pword: ", pword);
				}
        	}
        });
        
        noLoginButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(LoginScreen.this, RegisterScreen.class);
                startActivity(i);
        	}
        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login_screen, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}