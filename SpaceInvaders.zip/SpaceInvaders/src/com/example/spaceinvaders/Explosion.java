package com.example.spaceinvaders;

import java.util.Random;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Explosion 
{
	RectF rect;
    Random generator = new Random();
    private Bitmap explodeImg;
    private float length;
    private float height;
    private float x;
    private float y;
    private float shipSpeed;
    public final int LEFT = 1;
    public final int RIGHT = 2;
    private int shipMoving = RIGHT;
    private boolean isVisible;
    
    public Explosion(Context context, int row, int column, int screenX, int screenY) 
    {
        rect = new RectF();
        length = screenX / 15;
        height = screenY / 15;
        isVisible = false;
 
        int padding = screenX / 25;
 
        x = column * (length + padding);
        y = row * (length + padding/4);
 
        explodeImg = BitmapFactory.decodeResource(context.getResources(), R.drawable.explode);
 
        explodeImg = Bitmap.createScaledBitmap(explodeImg,
                (int) (length),
                (int) (height),
                false);
    }
    
    public void setInvisible(){
        isVisible = true;
    }
 
    public boolean getVisibility(){
        return isVisible;
    }
 
    public RectF getRect(){
        return rect;
    }
 
    public Bitmap getExplodeImg(){
        return explodeImg;
    }
 
    public float getX(){
        return x;
    }
 
    public float getY(){
        return y;
    }
 
    public float getLength(){
        return length;
    }
    
    public void update(long fps){
        if(shipMoving == LEFT){
            x = x - shipSpeed / fps;
        }
     
        if(shipMoving == RIGHT){
            x = x + shipSpeed / fps;
        }
     
        // Update rect which is used to detect hits
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x + length;
     
    }
    
    public void dropDownAndReverse(){
        if(shipMoving == LEFT){
            shipMoving = RIGHT;
        }else{
            shipMoving = LEFT;
            shipSpeed=shipSpeed+10;
        }
     
        y = y + height;
     
        shipSpeed = shipSpeed * 1.18f;
    }
    
    public boolean takeAim(float playerShipX, float playerShipLength){
    	 
        int randomNumber = -1;
     
        // If near the player
        if((playerShipX + playerShipLength > x && playerShipX + playerShipLength < x + length) ||
                (playerShipX > x && playerShipX < x + length)) {
     
            randomNumber = generator.nextInt(150);
            if(randomNumber == 0) {
                return true;
            }
        }
     
        // If firing randomly (not near the player) a 1 in 5000 chance
        randomNumber = generator.nextInt(150);
        if(randomNumber == 0){
            return true;
        }
        return false;
    }
}