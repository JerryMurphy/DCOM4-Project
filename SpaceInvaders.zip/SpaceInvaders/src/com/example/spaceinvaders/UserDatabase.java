package com.example.spaceinvaders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class UserDatabase extends SQLiteOpenHelper
{
	private static final String DB_NAME = "leaderboard";
	private static final String DB_TABLE_NAME = "users";
	private static final String DB_COLUMN_PLAYERID = "playerID";
	private static final String DB_COLUMN_USERNAME = "username";
	private static final String DB_COLUMN_EMAIL = "email";
	private static final String DB_COLUMN_PWORD = "pword";
	private static final String DB_COLUMN_SCORE = "score";

    private static final String[] COLUMNS = {DB_COLUMN_PLAYERID, 
    	DB_COLUMN_USERNAME, DB_COLUMN_EMAIL, DB_COLUMN_PWORD, DB_COLUMN_SCORE};
    
    private UserDatabase userDatabase;
    private Context context;
    private SQLiteDatabase db;
	
	public UserDatabase(Context context)
	{
		super(context, DB_NAME, null, 1);
	}
	
	public void onCreate(SQLiteDatabase db) 
	{
	    String CREATE_USERS_TABLE = "CREATE TABLE users ( " +
	      "playerID INTEGER PRIMARY KEY AUTOINCREMENT, " +
	      "username TEXT, " + 
	      "email TEXT, " + 
	      "pword TEXT, " + 
	      "score INTEGER)";
	    
	     db.execSQL(CREATE_USERS_TABLE);
	}
	
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
	{
		db.execSQL("DROP TABLE IF EXISTS users");
		
		this.onCreate(db);
		
		db.close();
	}
	
	public void addUser(User user)
	{
		SQLiteDatabase db = this.getReadableDatabase();
		
		ContentValues values = new ContentValues();
		values.put(DB_COLUMN_USERNAME, user.getUsername());
		values.put(DB_COLUMN_EMAIL, user.getEmail());
		values.put(DB_COLUMN_PWORD, user.getPword());
		values.put(DB_COLUMN_SCORE, user.getScore());
		
		db.insert(DB_TABLE_NAME, null, values);
		
		db.close();
	}
	
	public int updateUser(User user)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		
		ContentValues values = new ContentValues();
		values.put(DB_COLUMN_USERNAME, user.getUsername());
		values.put(DB_COLUMN_EMAIL, user.getEmail());
		values.put(DB_COLUMN_PWORD, user.getPword());
		values.put(DB_COLUMN_SCORE, user.getScore());
		
		int i = db.update(DB_TABLE_NAME, values, DB_COLUMN_PLAYERID + " = ?", 
				new String[] { String.valueOf(user.getPlayerID()) });
		
		db.close();
		
		return i;
	}
	
	public void deleteUser(User user)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		
		db.delete(DB_TABLE_NAME, DB_COLUMN_PLAYERID + " = ?", 
				new String[] { String.valueOf(user.getPlayerID()) });
		
		db.close();
	}
	
	public User getUser(String username)
	{
		SQLiteDatabase db = this.getReadableDatabase();
		
		Cursor cur = db.query(DB_TABLE_NAME, COLUMNS, " username = ?", 
				new String[] { String.valueOf(username) }, null, null, null, null);
		
		if(cur != null)
		{
			cur.moveToFirst();
		}
		
		User user = new User();
		user.setPlayerID(Integer.parseInt(cur.getString(0)));
		user.setUsername(cur.getString(1));
		user.setEmail(cur.getString(2));
		user.setPword(cur.getString(3));
		user.setScore(Integer.parseInt(cur.getString(4)));
		
		db.close();
		return user;
	}
	
	public List<User> getAllUsers() 
	{
	    List<User> users = new LinkedList<User>();
	 
	    String query = "SELECT * FROM " + DB_TABLE_NAME;
	 
	    SQLiteDatabase db = this.getWritableDatabase();
	    Cursor cur = db.rawQuery(query, null);
	 
	    User user = null;
	    
	    if (cur.moveToFirst()) 
	    {
	      do 
	      {
	         user = new User();
	         user.setPlayerID(Integer.parseInt(cur.getString(0)));
	   		 user.setUsername(cur.getString(1));
	   		 user.setEmail(cur.getString(2));
	   		 user.setPword(cur.getString(3));
	   		 user.setScore(Integer.parseInt(cur.getString(4)));
	         users.add(user);
	       } while (cur.moveToNext());
	     }
	    
	     db.close();
	     return users;
	   }
	
	public String getSingleEntry(String username) {
		
	    SQLiteDatabase db = this.getReadableDatabase();
	    String query = "SELECT " + DB_COLUMN_USERNAME + ", " + DB_COLUMN_PWORD + " FROM "
	    		+ DB_TABLE_NAME;
	    Cursor cur = db.rawQuery(query, null);
	    String a, b;
	    b = "USER DOESN'T EXIST";
	    if(cur.moveToFirst()){
	    	do {
	    		a = cur.getString(0);
	    		
	    		if(a.equals(username)){
	    			b = cur.getString(1);
	    			break;
	    		}
	    	}
	    	while(cur.moveToNext());
	    }
		return b;
	}
}