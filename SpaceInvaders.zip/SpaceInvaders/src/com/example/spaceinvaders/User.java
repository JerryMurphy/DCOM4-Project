package com.example.spaceinvaders;

public class User 
{
	private int playerID;
	private String username;
	private String email;
	private String pword;
	private int score;
	
	public User(){}
	
	public User(String username, String email, String pword, int score)
	{
		super();
		this.username = username;
		this.email = email;
		this.pword = pword;
		this.score = score;
	}

	public int getPlayerID() {
		return playerID;
	}

	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public String toString()
	{
		return "User [playerID=" + playerID + ", username=" + username
				+ ", email=" + email + ", pword=" + pword + ", score=" + score + "]";
	}

}
