package com.example.spaceinvaders;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Window;

public class GameScreen extends Activity 
{
    GameView gameView;
    Display display;
    Point size;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Used for opening the GameVie class and the other classes associated with it
        display = getWindowManager().getDefaultDisplay();
        size = new Point();
        display.getSize(size);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        gameView = new GameView(this, size.x, size.y);
        setContentView(gameView);
    }
 
    //Runs the game when the user taps the screen upon launching
    @Override
    protected void onResume() 
    {
        super.onResume();
        gameView.resume();
    }
 
    //Keeps the game paused when GameView is launched until the user taps the acreen
    @Override
    protected void onPause() 
    {
        super.onPause();
        gameView.pause();
    }
}