package com.example.spaceinvaders;

import java.util.Random;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Invader 
{
	private RectF rect;
    Random generator = new Random();
    private Bitmap bitmap1;
    private Bitmap bitmap2;
    private float length;
    private float height;
    private float x;
    private float y;
    private float shipSpeed;
    public final int left = 1;
    public final int right = 2;
    private int shipMoving = right;
    private boolean isVisible;
    
    public Invader(Context context, int row, int column, int screenX, int screenY) 
    {
    	//Set the dimensions for the Invaders
        rect = new RectF();
        length = screenX / 15;
        height = screenY / 15;
        isVisible = true;
 
        //Keep each Invader within each row a small distance between each other 
        int padding = screenX / 25;
 
        x = column * (length + padding);
        y = row * (length + padding);
 
        //Draw the invader images
        bitmap1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.ai1);
        bitmap2 = BitmapFactory.decodeResource(context.getResources(), R.drawable.ai2);
 
        bitmap1 = Bitmap.createScaledBitmap(bitmap1, (int)(length), (int)(height), false);
        bitmap2 = Bitmap.createScaledBitmap(bitmap2, (int)(length), (int)(height), false);
        
        shipSpeed = 20;
    }
    
    public void setInvisible(){
        isVisible = false;
    }
 
    public boolean getVisibility(){
        return isVisible;
    }
 
    public RectF getRect(){
        return rect;
    }
 
    public Bitmap getBitmap(){
        return bitmap1;
    }
 
    public Bitmap getBitmap2(){
        return bitmap2;
    }
 
    public float getX(){
        return x;
    }
 
    public float getY(){
        return y;
    }
 
    public float getLength(){
        return length;
    }
    
    public void update(long fps){
        if(shipMoving == left){
            x = x - shipSpeed / fps;
        }
     
        if(shipMoving == right){
            x = x + shipSpeed / fps;
        }
     
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x + length;
     
    }
    
    public void dropDownAndReverse(){
        if(shipMoving == left){
            shipMoving = right;
        }else{
            shipMoving = left;
            shipSpeed=shipSpeed+5;
        }
     
        y = y + height;
     
        shipSpeed = shipSpeed * 1.18f;
    }
    
    public boolean takeAim(float playerShipX, float playerShipLength){
    	 
        int randomNumber = -1;
        
        //Randomly generates the rate of fire from the invaders when the userShip is in sight 
        if((playerShipX + playerShipLength > x && playerShipX + playerShipLength < x + length) ||
                (playerShipX > x && playerShipX < x + length)) {
     
            randomNumber = generator.nextInt(1000);
            if(randomNumber == 0) {
                return true;
            }
        }
        
        randomNumber = generator.nextInt(2000);
        if(randomNumber == 0){
            return true;
        }
        return false;
    }
}