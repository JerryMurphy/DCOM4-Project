package com.example.spaceinvaders;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
  
public class GameView extends SurfaceView implements Runnable{
  
    private Context context;
    private Thread gameThread = null;
    private SurfaceHolder ourHolder;
    private  boolean playing;
    private boolean paused = true;
    private Canvas canvas;
    private Paint paint;
    private long fps;
    private long timeThisFrame;
    private int screenX;
    private int screenY;
    private UserShip userShip;
    private Bullet userBullet;
    private Bullet[] invadersBullets = new Bullet[200];
    private int nextBullet;
    private int maxInvaderBullets = 10;
    private Invader[] invaders = new Invader[60];
    private int numInvaders = 0;
    private DefenceBrick[] bricks = new DefenceBrick[400];
    private int numBricks;
    private SoundPool soundPool;
    private int userExplodeSound = -1; 
    private int invaderExplodeSound = -1; 
    private int shootSound = -1;
    private int fastInvaderSound1 = -1;
    private int fastInvaderSound2 = -1;
    private int score = 0;
    private int lives = 3; 
    private long fastInvaderSoundInterval = 1000;
    private boolean uhOrOh;
    private long lastMenaceTime = System.currentTimeMillis();
  
    public GameView(Context context, int x, int y){
    	
        super(context);

        this.context = context;
  
        ourHolder = getHolder();
        paint = new Paint();
  
        screenX = x;
        screenY = y;
  
        soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC,0);
  
        try{
            AssetManager assetManager = context.getAssets();
            AssetFileDescriptor descriptor;
 
            descriptor = assetManager.openFd("shoot.wav");
            shootSound = soundPool.load(descriptor, 0);
  
            descriptor = assetManager.openFd("invaderexplode.wav");
            invaderExplodeSound = soundPool.load(descriptor, 0);
  
            descriptor = assetManager.openFd("userexplode.wav");
            userExplodeSound = soundPool.load(descriptor, 0);
  
            descriptor = assetManager.openFd("fastinvader1.wav");
            fastInvaderSound1 = soundPool.load(descriptor, 0);
  
            descriptor = assetManager.openFd("fastinvader2.wav");
            fastInvaderSound2 = soundPool.load(descriptor, 0);
  
        }catch(IOException e){
            Log.e("Error", "Failed to load sound files");
        }
        prepareLevel();
    }
  
    private void prepareLevel(){
    	
    	userShip = new UserShip(context, screenX, screenY);
  
        userBullet = new Bullet(screenY);
  
        for(int i = 0; i < invadersBullets.length; i++){
            invadersBullets[i] = new Bullet(screenY);
        }

        numInvaders = 0;
        for(int column = 0; column < 6; column ++ ){
            for(int row = 0; row < 5; row ++ ){
                invaders[numInvaders] = new Invader(context, row, column, screenX, screenY);
                numInvaders ++;
            }
        }

        numBricks = 0;
        for(int shelterNumber = 0; shelterNumber < 4; shelterNumber++){
            for(int column = 0; column < 10; column ++ ) {
                for (int row = 0; row < 5; row++) {
                    bricks[numBricks] = new DefenceBrick(row, column, shelterNumber, screenX, screenY);
                    numBricks++;
                }
            }
        }
        fastInvaderSoundInterval = 1000;
    }
  
    @Override
    public void run() {
        while (playing) {
  
            long startFrameTime = System.currentTimeMillis();

            if(!paused){
                update();
            }

            draw();
  
            timeThisFrame = System.currentTimeMillis() - startFrameTime;
            if (timeThisFrame >= 1) {
                fps = 1000 / timeThisFrame;
            }
  
            if(!paused){
                if ((startFrameTime - lastMenaceTime)> fastInvaderSoundInterval){
                    if (uhOrOh){
                        soundPool.play(fastInvaderSound1, 1, 1, 0, 0, 1);
                    } 
                    else{
                        soundPool.play(fastInvaderSound2, 1, 1, 0, 0, 1);
                    }
  
                    lastMenaceTime = System.currentTimeMillis();
                    uhOrOh = !uhOrOh;
                }
            }
        }
    }
  
    private void update(){
  
        boolean bumped = false;
        boolean lost = false;
    
        userShip.update(fps);

        if(userBullet.getStatus()){
        	userBullet.update(fps);
        }
  
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()) {
                invadersBullets[i].update(fps);
            }
        }
  
        for(int i = 0; i < numInvaders; i++){
            if(invaders[i].getVisibility()) {
                invaders[i].update(fps);
                if(invaders[i].takeAim(userShip.getX(), userShip.getLength())){
                    if(invadersBullets[nextBullet].shoot(invaders[i].getX() + invaders[i].getLength() / 2, invaders[i].getY(), userBullet.DOWN)) {
                        nextBullet++;
                        if (nextBullet == maxInvaderBullets) {
                            nextBullet = 0;
                        }
                    }
                }
  
                if (invaders[i].getX() > screenX - invaders[i].getLength()
                        || invaders[i].getX() < 0){
  
                    bumped = true;
                }
            }
        }
  
        if(bumped){
            for(int i = 0; i < numInvaders; i++){
                invaders[i].dropDownAndReverse();
  
                if(invaders[i].getY() > screenY - screenY / 10){
                    lost = true;
                }
            }

            fastInvaderSoundInterval = fastInvaderSoundInterval - 80;
        }
        //Reset game if lost
        if(lost){
            prepareLevel();
        }
 
        if(userBullet.getImpactPointY() < 0){
        	userBullet.setInactive();
        }
  
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getImpactPointY() > screenY){
                invadersBullets[i].setInactive();
            }
        }
  
        if(userBullet.getStatus()) {
            for (int i = 0; i < numInvaders; i++) {
                if (invaders[i].getVisibility()) {
                    if (RectF.intersects(userBullet.getRect(), invaders[i].getRect())) {
                        invaders[i].setInvisible();
                        soundPool.play(invaderExplodeSound, 1, 1, 0, 0, 1);
                        userBullet.setInactive();
                        score = score + 10;

                        if(score == numInvaders * 10){
                            paused = true;
                            score = 0;
                            lives = 3;
                            prepareLevel();
                        }
                    }
                }
            }
        }
        //If the DefenceBricks have been hit by the Invader's bullets
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()){
                for(int j = 0; j < numBricks; j++){
                    if(bricks[j].getVisibility()){//While there is still at least one brick remaining
                        //Invader's bullet hits a brick
                    	if(RectF.intersects(invadersBullets[i].getRect(), bricks[j].getRect())){
                            invadersBullets[i].setInactive();
                            bricks[j].setInvisible();//Removes the brick that were hit
                        }
                    }
                }
            }
        }
        //If the DefenceBricks have been hit by the UserShip's bullets
        if(userBullet.getStatus()){
            for(int i = 0; i < numBricks; i++){
                if(bricks[i].getVisibility()){//While there is still at least one brick remaining
                    //UserShip's bullet hits a brick
                	if(RectF.intersects(userBullet.getRect(), bricks[i].getRect())){
                    	userBullet.setInactive();
                        bricks[i].setInvisible();//Removes the brick that were hit
                    }
                }
            }
        }
        //UserShip is hit by Invader's bullets
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()){
                if(RectF.intersects(userShip.getRect(), invadersBullets[i].getRect())){
                    invadersBullets[i].setInactive();
                    lives --;//Lives decreased by 1 when UserShip is hit by a bullet
                    soundPool.play(userExplodeSound, 1, 1, 0, 0, 1);
  
                    //User has no lives left
                    if(lives == 0){
                        paused = true;//Reset and start from the beginning
                        lives = 3;
                        score = 0; 
                        prepareLevel();
                        //Works but for commented out for testing purposes
                        Intent k = new Intent(context.getApplicationContext(), GameOverScreen.class );
                        context.startActivity(k);
                    }
                }
            }
        }
    }
    
    private void draw(){
    	//Draw the canvas
        if (ourHolder.getSurface().isValid()) {
            canvas = ourHolder.lockCanvas();
            canvas.drawColor(Color.BLACK);
  
            //Draw the UserShip
            canvas.drawBitmap(userShip.getBitmap(), userShip.getX(), screenY - 130, paint);
            
            //Draw and generate the Invaders
            for(int i = 0; i < numInvaders; i++){
                if(invaders[i].getVisibility()) {//While there is at least one Invaders remaining
                    if(uhOrOh) {//Swaps between the two bitmap images of Invaders every second
                        canvas.drawBitmap(invaders[i].getBitmap(), invaders[i].getX(), invaders[i].getY(), paint);
                    }else{
                        canvas.drawBitmap(invaders[i].getBitmap2(), invaders[i].getX(), invaders[i].getY(), paint);
                    }
                }
            }
            
            //Draw and displays the DefenceBricks
            for(int i = 0; i < numBricks; i++){
                if(bricks[i].getVisibility()){
                	paint.setColor(Color.GREEN);
                    canvas.drawRect(bricks[i].getRect(), paint);
                }
            }
  
            //Draw and displays the UserShip's Bullets
            if(userBullet.getStatus()){
            	paint.setColor(Color.GREEN);
                canvas.drawRect(userBullet.getRect(), paint);
            }
            
            //Draw and displays the Invader's bullets
            for(int i = 0; i < invadersBullets.length; i++){
                if(invadersBullets[i].getStatus()){
                    paint.setColor(Color.RED); 
                    canvas.drawRect(invadersBullets[i].getRect(), paint);
                }
            }

            //Draws the User's score from destroying invaders and lives left
            paint.setColor(Color.YELLOW);
            paint.setTextSize(20);
            canvas.drawText("Score: " + score + "   Lives: " + lives, 10,50, paint); 
            
            ourHolder.unlockCanvasAndPost(canvas);//Places everything onto the canvas such as the user and enemy ships
        }
    }

    /**Used for the start of the game where it is opened in paused mode 
     * User is required to tap on the screen once to start the game
     */
    //Pause the game when the GameScreen class is launched
    public void pause() {
        playing = false;//Game is paused
        try {
            gameThread.join();
        } catch (InterruptedException e) {//Problem with joining thread
            Log.e("Error:", "joining thread");
        }
    }

    //Starts the game when the user taps on the screen
    public void resume() {
        playing = true;//Game has started
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    /**
     * Responsible for the touch screen interaction with the game.
     * Required in order to unpause the game so that the game can start.
     * Designates the UserShip's movements and firing it's bullets.
     * Bottom half of the screen is used for moving the UserShip and top half is used for firing bullets.
     * Press and hold on which side of the bottom half of the screen where you want to move the UserShip.
     * Tap on the top half of the screen to fire off bullets.
     */
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
    	
    	//Starts the game when the user taps on the screen.
        paused = false;
        
        //Determines the users touch screen actions.
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
            //While the user's finger is on the screen.
            case MotionEvent.ACTION_DOWN:
  
            	//Determines where the UserShip goes based on where the user's finger is placed on the screen.
                if(motionEvent.getY() > screenY - screenY / 2) {
                    if (motionEvent.getX() > screenX / 2) {
                    	userShip.setMovementState(UserShip.DIRECTION_RIGHT);//Moves right.
                    } else {
                    	userShip.setMovementState(UserShip.DIRECTION_LEFT);//Moves left.
                    }
                }
                
                //Determines the firing of UserShip bullets
                if(motionEvent.getY() < screenY - screenY / 2) {
                    if(userBullet.shoot(userShip.getX() + userShip.getLength() / 2, screenY, userBullet.UP)){
                        soundPool.play(shootSound, 1, 1, 0, 0, 1);//Activates the shoot sound when screen is taped to fire bullets.
                    }
                }
                break;
  
            //While the user's finger is off the screen.
            case MotionEvent.ACTION_UP:
                //Stops the UserShip from moving when the user's finger is off the screen.
                if(motionEvent.getY() > screenY - screenY / 4) {
                	userShip.setMovementState(userShip.STOPPED);//UserShip movement is stopped.
                }
                break;
                
            //case MotionEvent.ACTION_MOVE:

        }
        return true;
    }
}