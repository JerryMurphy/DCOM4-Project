package com.example.spaceinvaders;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class Leaderboard extends Activity 
{
	TableRow dataRow;
	SQLiteDatabase newDB;
	private Context context;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_leaderboard);
		
		context = this;
		
		UserDatabase db = new UserDatabase(this);
		
	    TableLayout userLayout =(TableLayout)findViewById(R.id.userLayout);
	    
	    TableRow headerRow = new TableRow(context);
	    headerRow.setBackgroundColor(Color.parseColor("#FFFF00"));
	    headerRow.setLayoutParams(new TableLayout.LayoutParams
	    		(TableLayout.LayoutParams.MATCH_PARENT,
	           TableLayout.LayoutParams.WRAP_CONTENT));
	    
	    String[] headerText={"Rank", "Username", "Score"};
	    
	    for(String c : headerText) 
	    {
	        TextView header = new TextView(this);
	        header.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
	              TableRow.LayoutParams.WRAP_CONTENT));
	        header.setGravity(Gravity.CENTER);
	        header.setTextSize(16);
	        header.setPadding(5, 5, 5, 5);
	        header.setText(c);
	        headerRow.addView(header);
	      }
	      userLayout.addView(headerRow);
	    
	    newDB = db.getReadableDatabase();
	    newDB.beginTransaction();
	    
	    try
	    {
	        String selectQuery = "SELECT * FROM users";
	        Cursor cursor = newDB.rawQuery(selectQuery, null);
	        if(cursor.getCount() >0)
	        {
	           while (cursor.moveToNext()) 
	           {
	              String username = cursor.getString(cursor.getColumnIndex("username"));
	              int score = cursor.getInt(cursor.getColumnIndex("score"));
	              int rank = 0;
	              
	              TableRow dataRow = new TableRow(context);
	              dataRow.setLayoutParams(new TableLayout.LayoutParams
	            		  (TableLayout.LayoutParams.MATCH_PARENT,
	                   TableLayout.LayoutParams.WRAP_CONTENT));
	              
	              String[] colText={String.valueOf(rank), username, String.valueOf(score)};
	              
	              for(String text : colText) 
	              {
	                TextView data = new TextView(this);
	                data.setLayoutParams(new TableRow.LayoutParams
	                		(TableRow.LayoutParams.WRAP_CONTENT, 
	                				TableRow.LayoutParams.WRAP_CONTENT));
	                data.setGravity(Gravity.CENTER);
	                data.setTextSize(16);
	                data.setPadding(5, 5, 5, 5);
	                data.setText(text);
	                dataRow.addView(data);
	                rank++;
	              }
	              userLayout.addView(dataRow);
	           }
	        }
	        newDB.setTransactionSuccessful();
	      }
	      catch (SQLiteException e)
	      {
	        e.printStackTrace();

	      }
	      finally
	      {
	    	newDB.endTransaction();
	        db.close();
	      }
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.leaderboard, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
