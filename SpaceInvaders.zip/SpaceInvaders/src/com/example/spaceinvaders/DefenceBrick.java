package com.example.spaceinvaders;

import android.graphics.RectF;

public class DefenceBrick 
{
	private RectF rect;
	private boolean isVisible;
	private int width;
	private int height;
	private int brickPadding;
	private int shelterPadding;
	private int startHeight;
	
	public DefenceBrick(int row, int column, int shelterNumber, int screenX, int screenY)
	{
	    width = screenX / 60;
	    height = screenY / 90;
	    isVisible = true;
	    brickPadding = 0;
	    shelterPadding = screenX / 9;
	    startHeight = screenY - (screenY /8 * 2);
	    rect = new RectF(column * width + brickPadding + (shelterPadding * shelterNumber) + shelterPadding + shelterPadding * shelterNumber,
	            row * height + brickPadding + startHeight,
	            column * width + width - brickPadding + (shelterPadding * shelterNumber) + shelterPadding + shelterPadding * shelterNumber,
	            row * height + height - brickPadding + startHeight);
	}

	public RectF getRect(){
        return this.rect;
    }
 
    public void setInvisible(){
        isVisible = false;
    }
 
    public boolean getVisibility(){
        return isVisible;
    }
}