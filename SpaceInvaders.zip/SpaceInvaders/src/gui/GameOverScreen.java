package gui;

import com.spaceinvaders.R;

import database.UserDatabase;
import model.User;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

public class GameOverScreen extends Activity {
	
	private Button saveButton;
	private Button returnButton;
	private UserDatabase db;
	private SharedPreferences sharedpreferences;
	private SQLiteDatabase newDB;
	private String username;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.game_over_screen);
		getWindow().getDecorView().setBackgroundColor(Color.BLACK);
		
		saveButton = (Button) findViewById(R.id.saveButton);
		returnButton = (Button) findViewById(R.id.returnButton);
		
        db = new UserDatabase(this);
	    newDB = db.getWritableDatabase();

	    sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
		username = sharedpreferences.getString("username", null);
		//Toast.makeText(GameOverScreen.this,String.valueOf(username),Toast.LENGTH_LONG).show();
		
		saveButton.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View view){
				int score = sharedpreferences.getInt("score", 0);
		        String selectQuery = "UPDATE users SET score='" + score + "' WHERE username='" + username + "' AND '"
		        		+ score + "' > score";
		        Cursor cursor = newDB.rawQuery(selectQuery, null);
		        
		        for(User u: db.getAllUsers())
	         	{
			        if(cursor.getCount() > 0)
			        {
			           while(cursor.moveToNext())
			           {
			        	  /* if(score >= u.getScore())
			        	   {
			        		   Toast.makeText(GameOverScreen.this, "New Score Saved" ,Toast.LENGTH_LONG).show();*/
					           u.setScore(score);
	 				           db.updateUser(u);
			        	   /*}
			        	   else
			        	   {
			        		   Toast.makeText(GameOverScreen.this, "Score is lower than your high score", 
			        				   Toast.LENGTH_LONG).show();
			        	   }*/
			           }
					}
	         	}

        		Intent j = new Intent(GameOverScreen.this, MainMenu.class);
                startActivity(j);
             }
        });
		
		returnButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(GameOverScreen.this, MainMenu.class);
                startActivity(i);
        	}
        });
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		//Prevent the player from going back to the GameScreen and instead return to the MainMenu
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	        Intent i = new Intent(GameOverScreen.this, MainMenu.class);
	        startActivity(i);
	        return true;
	    }
	    return super.onKeyDown(keyCode, event);
	}
}