package gui;

import com.spaceinvaders.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainMenu extends Activity {
	
	private Button newGameButton;
	private Button leaderboardButton;
	private Button settingsButton;
	private Button loggedOutButton;
	private TextView welcome;
	private String loggedInUser;
	private SharedPreferences sharedpreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main_menu);
		getWindow().getDecorView().setBackgroundColor(Color.BLACK);
		
		sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
		loggedInUser = sharedpreferences.getString("username", null);
		welcome = (TextView) findViewById(R.id.welcome);
		welcome.setText("Welcome " + loggedInUser);
		
        newGameButton = (Button) findViewById(R.id.newGameButton);
        leaderboardButton = (Button) findViewById(R.id.leaderboardButton);
        settingsButton = (Button) findViewById(R.id.settingsButton);
        loggedOutButton = (Button) findViewById(R.id.loggedOutButton);
        
        newGameButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(MainMenu.this, CharacterSelection.class);
                startActivity(i);
        	}
        });
        
        leaderboardButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(MainMenu.this, Leaderboard.class);
                startActivity(i);
        	}
        });
        
        settingsButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(MainMenu.this, SettingsScreen.class);
                startActivity(i);
        	}
        });
        
        loggedOutButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
		        clear();
        		Intent i = new Intent(MainMenu.this, LoginScreen.class);
                startActivity(i);
				Toast.makeText(MainMenu.this, String.valueOf(loggedInUser),Toast.LENGTH_LONG).show();
        	}
        });
	}
	public void clear()
	{
	     Editor editor = sharedpreferences.edit();
	     editor.clear();
	     editor.commit();
	}
}