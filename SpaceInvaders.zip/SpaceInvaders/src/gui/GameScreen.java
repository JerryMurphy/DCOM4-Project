package gui;

import view.GameView;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Display;
import android.view.Window;

public class GameScreen extends Activity 
{
    private GameView gameView;
    private Display display;
    private Point size;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Used for opening the GameView class and the other classes associated with it
        display = getWindowManager().getDefaultDisplay();
        size = new Point();
        display.getSize(size);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        gameView = new GameView(this, size.x, size.y);
        
        /*if(getIntent().hasExtra("image")) 
        {
        	Bundle extras = getIntent().getExtras();
        	byte[] byteArray = extras.getByteArray("image");

        	Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        	Canvas canvas = new Canvas();
            canvas.drawBitmap(bmp, 0, 0, null);
        }*/
        setContentView(gameView);
    }
 
    //Runs the game when the user taps the screen upon launching
    @Override
    protected void onResume() 
    {
        super.onResume();
        gameView.resume();
    }
 
    //Keeps the game paused when GameView is launched until the user taps the screen
    @Override
	public void onPause() 
    {
        super.onPause();
        gameView.pause();
    }
    
    public void saveSound(Context context, String key, int value) {
		SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }
}