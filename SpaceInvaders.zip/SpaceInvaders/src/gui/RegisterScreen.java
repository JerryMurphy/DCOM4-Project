package gui;

import java.util.List;
import com.spaceinvaders.R;
import database.UserDatabase;
import model.User;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterScreen extends Activity 
{
	private UserDatabase db;
    private EditText usernameField;
    private EditText emailField;
    private EditText pwordField;
    private Button createAccountButton;
    private Button alreadyRegisteredButton;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_screen);
        
        db = new UserDatabase(this);
        
        usernameField = (EditText) findViewById(R.id.usernameField);
        emailField = (EditText) findViewById(R.id.emailField);
        pwordField = (EditText) findViewById(R.id.pwordField);
        createAccountButton = (Button) findViewById(R.id.createAccountButton);
		alreadyRegisteredButton = (Button) findViewById(R.id.alreadyRegisteredButton);
        
        createAccountButton.setOnClickListener(new View.OnClickListener() 
        {
        	//InputStream is = null;
        	public void onClick(View view)
        	{
                String username = usernameField.getText().toString();
                String email = emailField.getText().toString();
                String pword = pwordField.getText().toString();
                
                if(username.equals("") || email.equals("") || pword.equals(""))
                {
                    Toast t = Toast.makeText(RegisterScreen.this, "Empty Field", Toast.LENGTH_SHORT);
                    t.show();               
                }
                else
                {
                	User user = new User();
                    user.setUsername(username);
                    user.setEmail(email);
                    user.setPword(pword);
                    user.setScore(0);
                    db.addUser(user);
                    Toast.makeText(RegisterScreen.this, "User created", Toast.LENGTH_SHORT).show();
 
            		Intent i = new Intent(RegisterScreen.this, LoginScreen.class);
                    startActivity(i);
                }
        	}
        });
        
        alreadyRegisteredButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(RegisterScreen.this, LoginScreen.class);
                startActivity(i);
        	}
        });
	}
}