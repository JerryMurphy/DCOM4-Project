package gui;

import com.spaceinvaders.R;

import database.UserDatabase;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;

public class SplashScreen extends Activity {
	
	UserDatabase userDatabase;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.splash_screen);
		getWindow().getDecorView().setBackgroundColor(Color.BLACK);
		
		Thread background = new Thread() 
		{
            public void run() 
            {
                try 
                {
                    //sleep(5*1000);
                	sleep(5*100);
                    Intent i = new Intent(SplashScreen.this, MainMenu.class);
                    startActivity(i);
                    finish();
                     
                } catch (Exception e) 
                {
                	e.printStackTrace();
                }
            }
        };
        background.start();
	}
}