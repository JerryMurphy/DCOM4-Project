package gui;

import com.spaceinvaders.R;
import database.UserDatabase;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginScreen extends Activity 
{
	private EditText usernameField;
    private EditText pwordField;
    private Button loginButton;
    private Button noLoginButton;
    private UserDatabase userDatabase;
    private SharedPreferences sharedpreferences;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		userDatabase = new UserDatabase(this);
		setContentView(R.layout.login_screen);
        setTitle(R.string.title_login_screen);

        usernameField = (EditText) findViewById(R.id.usernameField);
        pwordField = (EditText) findViewById(R.id.pwordField);
        loginButton = (Button) findViewById(R.id.loginButton);
        noLoginButton = (Button) findViewById(R.id.noLoginButton);
        
        userDatabase = new UserDatabase(getApplicationContext());
        
        sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
        
        loginButton.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View view){
        		
        		String username = usernameField.getText().toString();
        		String pword = pwordField.getText().toString();

        		String storedUser = userDatabase.getSingleEntry(username);
        		if (pword.equals(storedUser)) {
					Intent i = new Intent(LoginScreen.this, SplashScreen.class);
			        sharedpreferences.edit().putBoolean("loggedIn", true).commit();
			        sharedpreferences.edit().putString("username", username).commit();
	                startActivity(i);
	                /*Toast.makeText(LoginScreen.this,
							String.valueOf(storedUser),
							Toast.LENGTH_LONG).show();*/
				} else {
					Toast.makeText(LoginScreen.this,
							"Incorrect Login Details",
							Toast.LENGTH_LONG).show();
				}
        	}
        });
        
        noLoginButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(LoginScreen.this, RegisterScreen.class);
                startActivity(i);
        	}
        });
	}
}