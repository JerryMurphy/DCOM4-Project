package gui;

import java.util.ArrayList;
import java.util.List;

import com.spaceinvaders.R;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

public class SettingsScreen extends Activity {
	
	private Switch soundSwitch;
	private Spinner theme;
	private Spinner background;
	private ArrayAdapter<CharSequence> themeAdapter;
	private ArrayAdapter<CharSequence> backgroundAdapter;
	private SharedPreferences sharedpreferences;
    private boolean switchOff;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_screen);

	    sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
		
		soundSwitch = (Switch) findViewById(R.id.soundSwitch);
		soundSwitch.setChecked(true);
		
		soundSwitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			 @Override
			 public void onCheckedChanged(CompoundButton buttonView,  boolean isChecked) {
			     if(!isChecked){
					 sharedpreferences.edit().putBoolean("switchOff", false).commit();
					 switchOff = true;
					 Toast.makeText(SettingsScreen.this,
								"OFF",
								Toast.LENGTH_LONG).show();
			     }
			     else
			     {
			    	 switchOff = false;
			     }
			  }
		});
	    SharedPreferences.Editor editor = sharedpreferences.edit();
	    editor.putBoolean("switchOff", switchOff);
	    editor.commit();
		
		theme = (Spinner) findViewById(R.id.theme);
		background = (Spinner) findViewById(R.id.background);
	    
		themeAdapter = ArrayAdapter.createFromResource(SettingsScreen.this, R.array.themes, android.R.layout.simple_spinner_item);
        themeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        theme.setAdapter(themeAdapter);

        backgroundAdapter = ArrayAdapter.createFromResource(this, R.array.backgrounds, android.R.layout.simple_spinner_item);
        backgroundAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        background.setAdapter(backgroundAdapter);
        
    	theme.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    	background.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        
        theme.setSelection(sharedpreferences.getInt("themeSelection", 0));
        background.setSelection(sharedpreferences.getInt("backgroundSelection", 0));
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.settings_screen, menu);
		return true;
	}
	
	public class CustomOnItemSelectedListener implements OnItemSelectedListener {

		  public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
			String selectedTheme = parent.getSelectedItem().toString();
			String selectedBackground = parent.getSelectedItem().toString();
			
			if(selectedTheme.equals("Default Theme"))
			{
		        backgroundAdapter = ArrayAdapter.createFromResource(SettingsScreen.this, R.array.backgrounds, android.R.layout.simple_spinner_item);
		        backgroundAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        background.setAdapter(backgroundAdapter);
		        
		        if(selectedBackground.equals("Pitch Black"))
		        {
		        }
		        if(selectedBackground.equals("Stars"))
		        {
		        	
		        }
		        if(selectedBackground.equals("Galaxy"))
		        {
		        	
		        }
		        if(selectedBackground.equals("Supernova"))
		        {
		        	
		        }
			}
			
			if(selectedTheme.equals("Star Wars"))
			{
		        backgroundAdapter = ArrayAdapter.createFromResource(SettingsScreen.this, R.array.starwarsBackgrounds, android.R.layout.simple_spinner_item);
		        backgroundAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        background.setAdapter(backgroundAdapter);
		        
		        if(selectedBackground.equals("Death Star"))
		        {
		        	/*Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.deathstar);
		        	ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        	bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
		        	byte[] byteArray = stream.toByteArray();
		        	Intent i = new Intent(SettingsScreen.this, GameScreen.class);
		        	i.putExtra("image", bitmap);*/
		        }
		        if(selectedBackground.equals("sf"))
		        {
		        }
		        if(selectedBackground.equals("sff"))
		        {
		        	
		        }
		        if(selectedBackground.equals("as"))
		        {
		        	
		        }
			}
			
			if(selectedTheme.equals("Star Trek"))
			{
		        backgroundAdapter = ArrayAdapter.createFromResource(SettingsScreen.this, R.array.startrekBackgrounds, android.R.layout.simple_spinner_item);
		        backgroundAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        background.setAdapter(backgroundAdapter);
		        
		        if(selectedBackground.equals("Into Darkness"))
		        {
		        	/*Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.deathstar);
		        	ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        	bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
		        	byte[] byteArray = stream.toByteArray();
		        	Intent i = new Intent(SettingsScreen.this, GameScreen.class);
		        	i.putExtra("image", bitmap);*/
		        }
		        if(selectedBackground.equals("Voyager"))
		        {
		        }
		        if(selectedBackground.equals("fdj"))
		        {
		        	
		        }
		        if(selectedBackground.equals("ds"))
		        {
		        	
		        }
			}
			
			if(selectedTheme.equals("Angry Birds"))
			{
		        backgroundAdapter = ArrayAdapter.createFromResource(SettingsScreen.this, R.array.angrybirdsBackgrounds, android.R.layout.simple_spinner_item);
		        backgroundAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        background.setAdapter(backgroundAdapter);
		        
		        if(selectedBackground.equals("drer"))
		        {
		        	/*Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.deathstar);
		        	ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        	bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
		        	byte[] byteArray = stream.toByteArray();
		        	Intent i = new Intent(SettingsScreen.this, GameScreen.class);
		        	i.putExtra("image", bitmap);*/
		        }
		        if(selectedBackground.equals("er"))
		        {
		        }
		        if(selectedBackground.equals("we"))
		        {
		        	
		        }
		        if(selectedBackground.equals("qw"))
		        {
		        	
		        }
			}
			
			sharedpreferences.edit().putString("themeSelected", theme.getItemAtPosition(pos).toString()).commit();
			sharedpreferences.edit().putString("backgroundSelected", background.getItemAtPosition(pos).toString()).commit();

	        SharedPreferences.Editor editor = sharedpreferences.edit();
	        int selectedThemePos = theme.getSelectedItemPosition();
	        int selectedBackgroundPos = background.getSelectedItemPosition();
	        editor.putInt("themeSelection", selectedThemePos);
	        editor.putInt("backgroundSelection", selectedBackgroundPos);
	        editor.commit();
		  }

		  @Override
		  public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
		  }

		}
}