package gui;

import com.spaceinvaders.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class CharacterSelection extends Activity {
	
	private Button startGameButton;
	private TextView themeText;
	private TextView backgroundText;
	private String themeSelected;
	private String backgroundSelected;
    private RadioGroup characters;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.character_selection);
		getWindow().getDecorView().setBackgroundColor(Color.BLACK);
		
        characters = (RadioGroup) findViewById(R.id.characters);
        
        characters.setOnCheckedChangeListener(new OnCheckedChangeListener() {
        	 @Override
        	 public void onCheckedChanged(RadioGroup group, int checkedId) {
        	     if(checkedId == R.id.characterOne) 
        	     {

        	     } 
        	     else if(checkedId == R.id.characterTwo) 
        	     {
        	     }
        	     else if(checkedId == R.id.characterThree)
        	     {
        	    	 
        	     }
        	     else if(checkedId == R.id.characterFour)
        	     {
        	    	 
        	     }
             }
	    });

		startGameButton = (Button) findViewById(R.id.startGameButton);
		themeText = (TextView) findViewById(R.id.themeText);
		backgroundText = (TextView) findViewById(R.id.backgroundText);
		
		startGameButton.setOnClickListener(new View.OnClickListener() 
        {
        	public void onClick(View view)
        	{
        		Intent i = new Intent(CharacterSelection.this, GameScreen.class);
                startActivity(i);
        	}
        });
		
		SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
		themeSelected = sharedpreferences.getString("themeSelected", null);
		backgroundSelected = sharedpreferences.getString("backgroundSelected", null);
		themeText.setText("Theme: " + " " + themeSelected);
		backgroundText.setText("Background: " + " " + backgroundSelected);
		
		getDefaultBackgrounds();
	}
	
	public void getDefaultBackgrounds()
	{
		if(backgroundSelected.equals("Voyager"))
		{
		   Toast.makeText(CharacterSelection.this, String.valueOf(themeSelected),Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.character_selection, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
