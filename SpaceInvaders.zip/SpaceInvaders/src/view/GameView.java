package view;

import com.spaceinvaders.R;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.SoundPool;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import gui.GameOverScreen;
import model.Bricks;
import model.Bullet;
import model.Invader;
import model.UserShip;
  
public class GameView extends SurfaceView implements Runnable{
  
    private Context context;
    private Thread gameThread = null;
    private SurfaceHolder ourHolder;
    private boolean playing;
    private boolean paused = true;
    private Canvas canvas;
    private Paint paint;
    private long fps;
    private long timeThisFrame;
    private int screenX;
    private int screenY;
    private UserShip userShip;
    private Bullet userBullet;
    private int nextBullet;
    private int maxInvaderBullets = 10;
    private Bullet[] invadersBullets = new Bullet[maxInvaderBullets];
    private int numInvaders = 28;
    private int updateInvaders = numInvaders;
    private Invader[] invaders = new Invader[updateInvaders];
    private Bricks[] bricks = new Bricks[400];
    private int numBricks;
    private int score = 0;
    private int lives = 3; 
    private long fastInvaderSoundInterval;
    private boolean uhOrOh;
    private long lastMenaceTime;
    private AudioManager audioManager;
    private SoundPool soundPool;
    private int soundID[];
    private float actVolume;
    private float maxVolume;
    private float volume;
    private SharedPreferences sharedPreferences;
    private boolean soundOnOrOff;
    private Intent passScore;
    private int wave = 0;
  
    public GameView(Context context, int x, int y) {

        super(context);
        
        this.context = context;
        
        passScore = new Intent(context.getApplicationContext(), GameOverScreen.class);

        ourHolder = getHolder();
        paint = new Paint();
  
        screenX = x;
        screenY = y;

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		soundOnOrOff = sharedPreferences.getBoolean("switchOff", false);
		
        if(soundOnOrOff == false)
        {
           audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
           actVolume = (float) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
           maxVolume = (float) audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
           volume = actVolume/maxVolume;
   	       Log.e("kkkk", "KK");
        }
        else
        {
    	   Log.e("jjjj", "JJ");
        }
    
        soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        soundID = new int[5];
        soundID[0] = soundPool.load(context, R.raw.fastinvader1, 1);
        soundID[1] = soundPool.load(context, R.raw.fastinvader2, 1);
        soundID[2] = soundPool.load(context, R.raw.invaderexplode, 1);
        soundID[3] = soundPool.load(context, R.raw.shoot, 1);
        soundID[4] = soundPool.load(context, R.raw.userexplode, 1);
        prepareLevel();
    }
  
    private void prepareLevel(){
  
    	userShip = new UserShip(context, screenX, screenY);
        userBullet = new Bullet(screenY);

        for(int i = 0; i < invadersBullets.length; i++){
            invadersBullets[i] = new Bullet(screenY);
        }
        
    	wave = wave + 1;

        numInvaders = 0;
        for(int column = 0; column < 7; column ++ ){
            for(int row = 0; row < 4; row ++ ){
                invaders[numInvaders] = new Invader(context, row, column, screenX, screenY);
                numInvaders++;
            }
        }

        numBricks = 0;
        for(int shelterNumber = 0; shelterNumber < 4; shelterNumber++){
            for(int column = 0; column < 10; column ++ ) {
                for (int row = 0; row < 5; row++) {
                    bricks[numBricks] = new Bricks(row, column, shelterNumber, screenX, screenY);
                    numBricks++;
                }
            }
        }
        fastInvaderSoundInterval = 1000;
    }
  
    @Override
    public void run() {
        while (playing) {
  
            long startFrameTime = System.currentTimeMillis();

            if(!paused){
                update();
            }

            draw();
  
            timeThisFrame = System.currentTimeMillis() - startFrameTime;
            if (timeThisFrame >= 1) {
                fps = 1000 / timeThisFrame;
            }
  
            if(!paused){
                if ((startFrameTime - lastMenaceTime)> fastInvaderSoundInterval){
                    if (uhOrOh){
                        soundPool.play(soundID[0], volume, volume, 1, 0, 1f);
                    } 
                    else{
                        soundPool.play(soundID[1], volume, volume, 1, 0, 1f);
                    }
  
                    lastMenaceTime = System.currentTimeMillis();
                    uhOrOh = !uhOrOh;
                }
            }
        }
    }
  
    private void update(){
    	  
        boolean bumped = false;
    
        userShip.update(fps);

        if(userBullet.getStatus()){
        	userBullet.update(fps);
        }
  
        //Draw the Invader's bullets
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()) {
                invadersBullets[i].update(fps);
            }
        }
  
        //Invaders shoot at the UserShip
        for(int i = 0; i < numInvaders; i++){
            if(invaders[i].getVisibility()) {
                invaders[i].update(fps);
                if(invaders[i].takeAim(userShip.getX(), userShip.getLength())){
                    if(invadersBullets[nextBullet].shoot(invaders[i].getX() + invaders[i].getLength() / 2, invaders[i].getY(), userBullet.DOWN)) {
                        nextBullet++;
                        if (nextBullet == maxInvaderBullets) {
                            nextBullet = 0;
                        }
                    }
                }
  
                //If the Invaders bump against the right wall
                if (invaders[i].getX() > screenX - invaders[i].getLength()
                        || invaders[i].getX() < 0){
                    bumped = true;
                }
            }
        }
  
        //Drop down and go back to the left wall if bumped
        if(bumped){
            for(int i = 0; i < numInvaders; i++){
                invaders[i].dropDownAndReverse();
  
                //If the Invaders reach the bottom of the screen
                if(invaders[i].getY() > screenY - screenY / 5){
			        sharedPreferences.edit().putInt("score", score).commit();
                    context.startActivity(passScore);
                }
            }

            fastInvaderSoundInterval = fastInvaderSoundInterval - 80;
        }
        //Reset UserBullet if it misses Invader(s)
        if(userBullet.getImpactPointY() < 0){
        	userBullet.setInactive();
        }
        
        
  
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getImpactPointY() > screenY){
                invadersBullets[i].setInactive();
            }
        }
  
        if(userBullet.getStatus()) {
            for(int i = 0; i < numInvaders; i++) {
                if(invaders[i].getVisibility()) {
                    if(RectF.intersects(userBullet.getRect(), invaders[i].getRect())) {
                        invaders[i].setInvisible();
                        soundPool.play(soundID[2], volume, volume, 1, 0, 1f);
                        userBullet.setInactive();
                        score = score + 10;
                    	updateInvaders--;
                        
                        //Start new game with points from previous round
                        if(updateInvaders == 0){
                        	paused = true;
                        	updateInvaders = 28;
                            lives = 3;
                            prepareLevel();
                        }
                    }
                }
            }
        }
        //If the Bricks have been hit by the Invader's bullets
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()){//Check if bullet is still active
                for(int j = 0; j < numBricks; j++){
                    if(bricks[j].getVisibility()){//While there is still at least one brick remaining
                        //Invader's bullet hits a brick
                    	if(RectF.intersects(invadersBullets[i].getRect(), bricks[j].getRect())){
                            invadersBullets[i].setInactive();
                            bricks[j].setInvisible();//Removes the brick that were hit
                        }
                    }
                }
            }
        }
        //If the DefenceBricks have been hit by the UserShip's bullets
        if(userBullet.getStatus()){
            for(int i = 0; i < numBricks; i++){
                if(bricks[i].getVisibility()){//While there is still at least one brick remaining
                    //UserShip's bullet hits a brick
                	if(RectF.intersects(userBullet.getRect(), bricks[i].getRect())){
                    	userBullet.setInactive();//Bullet disappears
                        bricks[i].setInvisible();//Removes the brick that were hit
                    }
                }
            }
        }
        //UserShip is hit by Invader's bullets
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()){
                if(RectF.intersects(userShip.getRect(), invadersBullets[i].getRect())){
                    invadersBullets[i].setInactive();
                    lives --;//Lives decreased by 1 when UserShip is hit by a bullet
                    soundPool.play(soundID[4], volume, volume, 1, 0, 1f);
  
                    //User has no lives left
                    if(lives == 0){
    			        sharedPreferences.edit().putInt("score", score).commit();
                        context.startActivity(passScore);
                    }
                }
            }
        } 
    }
    
    /**Draw all the components for the game onto the screen
     * Draws the UserShip, Invaders and Bricks 
     * Display the score and remaining lives
     */
    private void draw(){
    	//Draw the canvas
        if (ourHolder.getSurface().isValid()) {
            canvas = ourHolder.lockCanvas();
            //canvas.drawColor(Color.BLACK);
            canvas.drawBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.deathstar), 0, 0, null);
  
            // Now draw the player spaceship
            canvas.drawBitmap(userShip.getBitmap(), userShip.getX(), screenY - 50, paint);
  
            //Draw and generate the Invaders
            for(int i = 0; i < numInvaders; i++){
                if(invaders[i].getVisibility()) {//While there is at least one Invaders remaining
                    if(uhOrOh) {//Swaps between the two bitmap images of Invaders every second
                        canvas.drawBitmap(invaders[i].getBitmap(), invaders[i].getX(), invaders[i].getY(), paint);
                    }else{
                        canvas.drawBitmap(invaders[i].getBitmap2(), invaders[i].getX(), invaders[i].getY(), paint);
                    }
                }
            }
  
            //Draw and displays the Bricks
            for(int i = 0; i < numBricks; i++){
                if(bricks[i].getVisibility()){
                	paint.setColor(Color.GREEN);
                    canvas.drawRect(bricks[i].getRect(), paint);
                }
            }
  
            //Draw and displays the UserShip's Bullets
            if(userBullet.getStatus()){
            	paint.setColor(Color.GREEN);
                canvas.drawRect(userBullet.getRect(), paint);
            }
            
            //Draw and displays the Invader's bullets
            for(int i = 0; i < invadersBullets.length; i++){
                if(invadersBullets[i].getStatus()){
                    paint.setColor(Color.RED); 
                    canvas.drawRect(invadersBullets[i].getRect(), paint);
                }
            }
  
            //Draws the User's score from destroying invaders and remaining lives
            paint.setColor(Color.YELLOW);
            paint.setTextSize(20);
            canvas.drawText("Wave: " + wave, 10, 30, paint);
            canvas.drawText("Score: " + score + "  Lives: " + lives, 10, 60, paint);
            
            ourHolder.unlockCanvasAndPost(canvas);//Places everything onto the canvas such as the user and enemy ships
        }
    }
  
    /**Used for the start of the game where it is opened in paused mode 
     * User is required to tap on the screen once to start the game
     */
    //Pause the game when the GameScreen class is launched
    public void pause() {
        playing = false;//Game is paused
        try {
            gameThread.join();
        } catch (InterruptedException e) {//Problem with joining thread
            Log.e("Error:", "joining thread");
        }
    }

    //Starts the game when the user taps on the screen
    public void resume() {
        playing = true;//Game has started
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    /**
     * Responsible for the touch screen interaction with the game.
     * Required in order to resume the game so that the game can start.
     * Designates the UserShip's movements and firing it's bullets.
     * Bottom half of the screen is used for moving the UserShip and top half is used for firing bullets.
     * Bottom half refers to the area below the DefenceBricks
     * Top half refers to the area above the DefenceBricks
     * Press and hold on which side of the bottom half of the screen where you want to move the UserShip.
     * Tap on the top half of the screen to fire off bullets.
     */
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
    	
    	//Starts the game when the user taps on the screen.
        paused = false;
        
        //Determines the users touch screen actions.
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
            //While the user's finger is on the screen.
            case MotionEvent.ACTION_DOWN:
            	//Determines where the UserShip goes based on where the user's finger is placed on the screen.
                if(motionEvent.getY() > screenY - screenY / 5) { 
                    if (motionEvent.getX() > screenX - screenX / 4) {
                    	userShip.setMovementState(UserShip.DIRECTION_RIGHT);//Moves right.
                    } else {
                    	userShip.setMovementState(UserShip.DIRECTION_LEFT);//Moves left.
                    }
                }
                
                //Determines the firing of UserShip bullets
                if(motionEvent.getY() < screenY - screenY / 4) {
                    if(userBullet.shoot(userShip.getX() + userShip.getLength() / 2, screenY, userBullet.UP)){
                        soundPool.play(soundID[3], volume, volume, 1, 0, 1f);
                    }
                }
                break;
  
            //While the user's finger is off the screen.
            case MotionEvent.ACTION_UP:
                //Stops the UserShip from moving when the user's finger is off the screen.
                if(motionEvent.getY() > screenY - screenY / 5) {
                	userShip.setMovementState(userShip.STOPPED);//UserShip movement is stopped.
                }
                break;
                
            //case MotionEvent.ACTION_MOVE:
        }
        return true;
    }
}